# template
 Template is my own customizzed laravel app, that will ease development faster.
To clone the app 

https://github.com/abuiman/template.git

Make sure you have run:

composer install

Now it seems packages are not installed. If they are, try running:

composer dump-autoload

Then run

composer global update

Try to to give permission for that vendor folder

sudo chmod -R 777 vendor

update your composer also

composer update
