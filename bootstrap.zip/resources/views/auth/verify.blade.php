<body  style="background-image: url(vendor/adminlte/dist/img/bl.jpg); background-repeat:no-repeat; background-size:100% 100%; width:100%; background-color: rgba(54,84,99,0.7);">

@section('classes_body')
login-page
page_bg 
@stop
@section('body_data')
style='background-image:url(/vendor/adminlte/dist/img/bl.jpg);'
@stop

@extends('adminlte::auth.verify')
