<body  style="background-image: url(vendor/adminlte/dist/img/event-bg.jpg); background-repeat:no-repeat; background-size:100% 100%; width:100%; background-color: rgba(54,84,99,0.7);">

@extends('adminlte::auth.passwords.confirm')
