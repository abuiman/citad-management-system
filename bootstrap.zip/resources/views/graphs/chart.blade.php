<h1>Chart</h1>
@section('plugins.Chartjs', true)