<body  style="background-image: url(vendor/adminlte/dist/img/bl.jpg); background-repeat:no-repeat; background-size:100% 100%; width:100%; background-color: rgba(54,84,99,0.7);">

<?php $__env->startSection('classes_body'); ?>
login-page
page_bg 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body_data'); ?>
style='background-image:url(/vendor/adminlte/dist/img/bl.jpg);'
<?php $__env->stopSection(); ?>



<?php echo $__env->make('adminlte::auth.verify', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\citad-event-of-the-week\resources\views/auth/verify.blade.php ENDPATH**/ ?>