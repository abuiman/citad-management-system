

<?php $__env->startSection('title', 'Permissions'); ?>

<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card card-primary card-outline">
                    <div class="card-header">
                        <h3 class="card-title">
                            <i class="fas fa-edit"></i>
                            
                        </h3>
                    </div>
                    
                    <div class="card">
                    <div class="card-body">
                    
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
            <h4 class="pull-left">Permission Management</h4>
            <?php if(Auth::user()->hasRole('admin')): ?>
                    <a class="btn btn-success text-right" href="<?php echo e(route('permissions.create')); ?>"> Create New Permission</a>
                <?php endif; ?>
            </div>
            <div class="modal-body">

    <div class="row">
        <div class="col-lg-12 margin-tb">
            <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success">
              <p><?php echo e($message); ?></p>
            </div>
            <?php endif; ?>
            <table class="table table-bordered">
             <tr>
               <th></th>
               <th>Name</th>
               <th>Action</th>
             </tr>
             <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $permit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($key+1); ?></td>
                <td><?php echo e($permit->name); ?></td>
                <td>
                   
                   <?php if(Auth::user()->hasRole('admin')): ?>
                    <a href="<?php echo e(route('permissions.edit',$permit->id)); ?>">
                    <button type="submit" class="btn btn-xs btn-default text-teal mx-1 shadow" title="Details">
                        <i class="fa fa-lg fa-fw fa-edit"></i>
                    </button>
                    </a>
                   <?php endif; ?>
                   
                    <form action="<?php echo e(route('permissions.destroy',$permit->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-xs btn-default text-teal mx-1 shadow" title="Details">
                        <i class="fa fa-lg fa-fw fa-trash"></i>
                    </button>
                </form>
                </td>
              </tr>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            <?php if($permissions->hasPages()): ?>
                <div class="clear:both;margin-left:12px;">
                    <?php echo e($permissions->onEachSide(4)->links()); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
</div>
    </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\citad-event-of-the-week\resources\views/permissions/index.blade.php ENDPATH**/ ?>